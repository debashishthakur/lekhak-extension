(async () => {
  console.log('🚀 WandPen content script starting to load...');
  
  if (window.__wandpenInjected) {
    console.log('⚠️ WandPen already injected, skipping');
    return;
  }
  
  window.__wandpenInjected = true;
  console.log('✅ WandPen content script injected successfully');

  // Enhanced badge CSS with better design inspired by reference extension
  const BADGE_CSS = `
    :host { all: initial; }
    .badge-wrapper {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 2147483646;
      pointer-events: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .badge-wrapper.visible {
      pointer-events: auto;
    }
    .badge {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 50%;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4), 0 2px 4px rgba(0, 0, 0, 0.1);
      cursor: pointer;
      position: relative;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      transform: scale(0);
      opacity: 0;
    }
    .badge-wrapper.visible .badge {
      transform: scale(1);
      opacity: 1;
      animation: badgeAppear 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }
    @keyframes badgeAppear {
      0% {
        transform: scale(0) rotate(-180deg);
        opacity: 0;
      }
      50% {
        transform: scale(1.1) rotate(10deg);
      }
      100% {
        transform: scale(1) rotate(0deg);
        opacity: 1;
      }
    }
    .badge:hover {
      transform: scale(1.1);
      box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5), 0 3px 6px rgba(0, 0, 0, 0.15);
      background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    }
    .badge:active {
      transform: scale(0.95);
    }
    .badge-icon {
      width: 20px;
      height: 20px;
      color: white;
      font-weight: bold;
      font-size: 16px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      user-select: none;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .badge::before {
      content: '';
      position: absolute;
      inset: -2px;
      background: linear-gradient(135deg, #667eea, #764ba2, #f093fb, #f5576c);
      border-radius: 50%;
      z-index: -1;
      opacity: 0;
      transition: opacity 0.3s ease;
      animation: rotate 3s linear infinite;
      filter: blur(8px);
    }
    .badge:hover::before {
      opacity: 0.6;
    }
    @keyframes rotate {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .badge-tooltip {
      position: absolute;
      bottom: 100%;
      left: 50%;
      transform: translateX(-50%) translateY(-8px);
      background: #1f2937;
      color: white;
      padding: 4px 8px;
      border-radius: 6px;
      font-size: 11px;
      white-space: nowrap;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.2s ease;
    }
    .badge:hover .badge-tooltip {
      opacity: 1;
    }
    .badge-tooltip::after {
      content: '';
      position: absolute;
      top: 100%;
      left: 50%;
      transform: translateX(-50%);
      border: 4px solid transparent;
      border-top-color: #1f2937;
    }
  `;

  const PANEL_CSS = `
    :host { all: initial; }
    
    .panel {
      position: fixed;
      top: 0;
      left: 0;
      width: 350px;
      height: 235px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
      border: 1px solid #e5e7eb;
      display: none;
      flex-direction: column;
      z-index: 2147483647;
      transform: scale(0.95);
      opacity: 0;
      transition: all 200ms cubic-bezier(0.4, 0, 0.2, 1);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Inter', sans-serif;
      font-size: 12px;
      color: #111827;
      overflow: hidden;
    }
    
    /* Create a positioning context for the loading overlay */
    .panel .loading-overlay {
      position: absolute;
    }
    
    .panel.visible {
      display: flex;
      opacity: 1;
      transform: scale(1);
    }
    
    /* Theme Toggle */
    .theme-toggle {
      position: absolute;
      top: 8px;
      right: 8px;
      width: 32px;
      height: 20px;
      border: none;
      background: #e5e7eb;
      border-radius: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      transition: all 0.3s ease;
      z-index: 10;
      padding: 2px;
    }
    
    .theme-toggle.dark {
      background: #374151;
      justify-content: flex-end;
    }
    
    .theme-toggle-icon {
      width: 16px;
      height: 16px;
      background: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
      font-size: 8px;
    }
    
    .theme-toggle.dark .theme-toggle-icon {
      background: #1f2937;
    }
    
    .theme-toggle:hover {
      transform: scale(1.05);
    }
    
    /* Dark Theme Styles */
    .panel.dark-theme {
      background: #1f2937;
      border: 1px solid #374151;
      color: white;
      transition: all 0.5s ease;
    }
    
    .panel.dark-theme .search-input {
      background: #1f2937;
      border-color: #374151;
      color: white;
    }
    
    .panel.dark-theme .search-input::placeholder {
      color: #9ca3af;
    }
    
    .panel.dark-theme .menu-item {
      color: #e5e7eb;
      border-color: #374151;
    }
    
    .panel.dark-theme .menu-item:hover {
      background: #374151;
      border-color: #4b5563;
    }
    
    .panel.dark-theme .menu-item.active {
      background: #3b82f6;
      border-color: #2563eb;
      color: white;
    }
    
    .panel.dark-theme .custom-prompt {
      background: #1f2937;
      border-color: #374151;
    }
    
    .panel.dark-theme .custom-input {
      background: #374151;
      border-color: #4b5563;
      color: white;
    }
    
    .panel.dark-theme .custom-input::placeholder {
      color: #9ca3af;
    }
    
    .panel.dark-theme .custom-buttons .btn {
      background: #374151;
      color: white;
      border-color: #4b5563;
    }
    
    .panel.dark-theme .custom-buttons .btn.primary {
      background: #3b82f6;
      border-color: #2563eb;
    }
    
    .panel.dark-theme .response-section {
      background: #1f2937;
      border-color: #374151;
      color: white;
    }
    
    .panel.dark-theme .response-actions .btn {
      background: #374151;
      color: white;
      border-color: #4b5563;
    }
    
    .panel.dark-theme .response-actions .btn:hover {
      background: #4b5563;
    }
    
    .panel.dark-theme .model-selector {
      background: #1f2937;
      color: white;
      border-color: #374151;
    }
    
    /* Additional dark theme styles for complete coverage */
    .panel.dark-theme * {
      color: white !important;
    }
    
    .panel.dark-theme .footer-section {
      background: #1f2937;
      border-top-color: #374151;
    }
    
    .panel.dark-theme .status {
      color: white !important;
    }
    
    .panel.dark-theme .menu-item span {
      color: #e5e7eb !important;
    }
    
    .panel.dark-theme .menu-item.active span {
      color: white !important;
    }
    
    .panel.dark-theme .ai-label {
      color: #e5e7eb !important;
    }
    
    .panel.dark-theme .custom-prompt p {
      color: #e5e7eb !important;
    }
    
    .panel.dark-theme .response-content {
      color: white !important;
    }
    
    .panel.dark-theme .response-content * {
      color: white !important;
    }
    
    .panel.dark-theme .result-text {
      background: #1f2937 !important;
      color: white !important;
      border-color: #374151 !important;
    }
    
    .panel.dark-theme .copy-result {
      background: #374151 !important;
      color: white !important;
      border-color: #4b5563 !important;
    }
    
    .panel.dark-theme .copy-result:hover {
      background: #4b5563 !important;
    }
    
    .panel.dark-theme .insert-result {
      background: #374151 !important;
      color: white !important;
      border-color: #4b5563 !important;
    }
    
    .panel.dark-theme .insert-result:hover {
      background: #4b5563 !important;
    }
    
    .panel.dark-theme .model-selector span {
      color: white !important;
    }
    
    /* Loading overlay in dark theme */
    .panel.dark-theme .loading-overlay {
      background: rgba(31, 41, 55, 0.9);
    }
    
    /* Result container in dark theme */
    .panel.dark-theme .result-container {
      background: #1f2937 !important;
    }
    
    .panel.dark-theme .result-container.active {
      background: #1f2937 !important;
      border-color: #374151 !important;
    }
    
    .panel.show {
      animation: panelShow 300ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
    }
    
    .panel.hide {
      animation: panelHide 200ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
    }
    
    @keyframes panelShow {
      0% {
        opacity: 0;
        transform: scale(0.95) translateY(-10px);
      }
      100% {
        opacity: 1;
        transform: scale(1) translateY(0);
      }
    }
    
    @keyframes panelHide {
      0% {
        opacity: 1;
        transform: scale(1) translateY(0);
      }
      100% {
        opacity: 0;
        transform: scale(0.95) translateY(-10px);
      }
    }
    
    /* Search Section */
    .search-section {
      padding: 2px 12px;
      border-bottom: 1px solid #e5e7eb;
      flex-shrink: 0;
    }

    .search-input-wrapper {
      position: relative;
      display: flex;
      align-items: center;
    }

    .search-icon {
      position: absolute;
      left: 8px;
      top: 50%;
      transform: translateY(-50%);
      width: 16px;
      height: 16px;
      color: #9ca3af;
      z-index: 1;
    }

    .search-input {
      width: 100%;
      padding: 8px 48px 8px 32px;
      background: white;
      border: none;
      outline: none;
      color: #6b7280;
      font-size: 14px;
      font-family: inherit;
    }

    .search-input::placeholder {
      color: #9ca3af;
    }


    /* Menu Section */
    .menu-section {
      flex: 1;
      overflow-y: visible;
      padding: 4px 8px;
    }
    
    /* Make the whole panel scrollable when content overflows */
    .panel {
      max-height: 80vh;
      overflow-y: auto;
    }

    .menu-item {
      width: 100%;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 6px 8px;
      border-radius: 6px;
      background: transparent;
      border: none;
      cursor: pointer;
      transition: background-color 0.2s;
      text-align: left;
      font-size: 12px;
      font-family: inherit;
      color: #111827;
      margin-bottom: 1px;
    }

    .menu-item:hover {
      background-color: #f9fafb;
    }

    .menu-item.active {
      background-color: #f3f4f6;
    }

    .menu-icon {
      width: 14px;
      height: 14px;
      color: #374151;
      flex-shrink: 0;
    }

    .menu-item span {
      color: #111827;
      font-weight: 400;
    }
    
    /* Footer Section */
    .footer-section {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 16px;
      background: white;
      border-radius: 0 0 16px 16px;
      flex-shrink: 0;
    }

    .footer-empty {
      color: #9ca3af;
      font-size: 14px;
    }

    .model-selector {
      display: flex;
      align-items: center;
      gap: 6px;
      background: transparent;
      border: none;
      cursor: pointer;
      color: #374151;
      font-size: 14px;
      font-family: inherit;
      transition: color 0.2s;
    }

    .model-selector:hover {
      color: #111827;
    }

    .chevron-icon {
      width: 14px;
      height: 14px;
    }
    
    .custom-prompt {
      display: none;
      flex-direction: column;
      gap: 10px;
      padding: 12px;
      background: #f9fafb;
      border-top: 1px solid #e5e7eb;
    }
    
    .custom-prompt.visible {
      display: flex;
    }
    
    .custom-input {
      border: 1px solid #d1d5db;
      border-radius: 6px;
      padding: 8px 12px;
      font-size: 12px;
      background: #ffffff;
      transition: all 150ms ease;
      resize: vertical;
      min-height: 60px;
      font-family: inherit;
    }
    
    .custom-input:focus {
      outline: none;
      border-color: #6b7280;
    }
    
    .custom-actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
    }
    
    .btn-secondary {
      padding: 6px 12px;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      background: #ffffff;
      color: #6b7280;
      font-size: 11px;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }
    
    .btn-secondary:hover {
      background: #f9fafb;
    }
    
    .btn-primary {
      padding: 6px 12px;
      border: none;
      border-radius: 6px;
      background: #374151;
      color: #ffffff;
      font-size: 11px;
      font-weight: 500;
      cursor: pointer;
      transition: all 150ms ease;
      font-family: inherit;
    }
    
    .btn-primary:hover {
      background: #111827;
    }
    
    .btn-primary:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    
    .result-container {
      display: none;
      flex-direction: column;
      gap: 12px;
      background: #f9fafb;
      border-radius: 8px;
      padding: 12px;
      border: 1px solid #e5e7eb;
      margin: 8px;
    }
    
    .result-container.visible {
      display: flex;
    }
    
    .result-text {
      font-size: 11px;
      line-height: 1.4;
      color: #374151;
      max-height: 80px;
      overflow-y: auto;
      white-space: pre-wrap;
      font-family: inherit;
    }
    
    .result-actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 8px;
    }
    
    .status {
      margin: 8px 0 0;
      font-size: 11px;
      color: rgba(75, 85, 99, 0.8);
      padding: 0 16px;
      font-family: inherit;
    }

    .status.error {
      color: #dc2626;
    }
    
    .loading {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #374151;
      font-size: 11px;
      font-family: inherit;
    }
    
    .spinner {
      width: 12px;
      height: 12px;
      border: 2px solid #e5e7eb;
      border-top: 2px solid #374151;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    
    /* Glass Blur Loading Overlay */
    .loading-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(255, 255, 255, 0.8);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10;
      opacity: 0;
      visibility: hidden;
      transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
      border-radius: 16px;
    }
    
    .loading-overlay.visible {
      opacity: 1;
      visibility: visible;
    }
    
    .loading-spinner {
      width: 32px;
      height: 32px;
      border: 3px solid rgba(55, 65, 81, 0.2);
      border-top: 3px solid #374151;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
    }
  `;

  // Enhanced state management with better defaults
  const state = {
    badge: null,
    panel: null,
    chat: null,
    selectionText: '',
    selectionRange: null,
    selectionEditable: null,
    selectionRect: null,
    suppressSelectionUpdates: false,
    lastCloseTime: 0,
    lastSelectionTime: 0,
    selectionDebounceTimer: null,
    scrollRAF: null,
    resizeRAF: null,
    isDarkTheme: false,
    debug: false
  };

  // Check if Chrome extension APIs are available
  const isExtensionContext = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync && chrome.runtime;
  
  // Utility functions for enhanced functionality
  const utils = {
    debounce(func, wait, immediate) {
      let timeout;
      return function executedFunction() {
        const context = this;
        const args = arguments;
        const later = function() {
          timeout = null;
          if (!immediate) func.apply(context, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
      };
    },
    
    throttle(func, limit) {
      let inThrottle;
      return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
          func.apply(context, args);
          inThrottle = true;
          setTimeout(() => inThrottle = false, limit);
        }
      }
    },
    
    async loadSettings() {
      // Re-check extension context each time - check both existence and sync API
      if (!isExtensionContext || !chrome.storage || !chrome.storage.sync) {
        console.log('📝 Using fallback settings (not in extension context)');
        return { theme: 'light', model: 'gemini' };
      }
      
      try {
        const result = await chrome.storage.sync.get(['wandpen_theme', 'wandpen_model']);
        return {
          theme: result.wandpen_theme || 'light',
          model: result.wandpen_model || 'gemini'
        };
      } catch (error) {
        console.warn('Failed to load settings:', error);
        return { theme: 'light', model: 'gemini' };
      }
    },
    
    async saveSettings(settings) {
      // Re-check extension context each time - check both existence and sync API
      if (!isExtensionContext || !chrome.storage || !chrome.storage.sync) {
        console.log('📝 Settings not saved (not in extension context)');
        return;
      }
      
      try {
        await chrome.storage.sync.set({
          wandpen_theme: settings.theme,
          wandpen_model: settings.model
        });
        console.log('📝 Settings saved successfully');
      } catch (error) {
        console.warn('Failed to save settings, continuing without persistence:', error);
        // Don't throw error - settings will just not persist, but functionality continues
        return;
      }
    },
    
    async sendMessage(message) {
      console.log('🚀 sendMessage called with:', message);
      console.log('🔍 Chrome runtime status:', {
        chromeExists: typeof chrome !== 'undefined',
        runtimeExists: !!chrome?.runtime,
        runtimeId: chrome?.runtime?.id,
        onMessage: !!chrome?.runtime?.onMessage
      });
      
      // Always try to send to extension first, fall back to mock only on failure
      try {
        // Check if chrome.runtime exists and is valid
        if (!chrome?.runtime?.id) {
          console.error('❌ Extension context invalidated');
          throw new Error('Extension context invalidated');
        }
        
        console.log('📤 Sending message to background script...');
        const startTime = Date.now();
        
        const response = await chrome.runtime.sendMessage(message);
        
        const duration = Date.now() - startTime;
        console.log(`📥 Received response in ${duration}ms:`, response);
        
        // Check if we got a valid response
        if (!response) {
          console.error('❌ No response from background script');
          throw new Error('No response from background script');
        }
        
        if (response.error) {
          console.error('❌ Background script returned error:', response.error);
          throw new Error(response.error);
        }
        
        console.log('✅ Message sent successfully');
        return response;
        
      } catch (error) {
        console.error('❌ Failed to send message to background:', error);
        
        // Check if this is a real extension environment that failed
        if (error.message.includes('Extension context invalidated') || 
            error.message.includes('message port closed')) {
          throw new Error('Extension disconnected. Please refresh the page.');
        }
        
        // Only use mock in development/testing
        if (typeof chrome === 'undefined' || !chrome.runtime) {
          console.warn('📝 Using mock response (not in extension context)');
          return await this.getMockResponse(message);
        }
        
        // Re-throw for real errors
        throw error;
      }
    },

    async getMockResponse(message) {
      await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
      
      const { selection = '', instruction = '' } = message;
      const mockResponses = {
        'improve': `${selection}\n\n[✨ Enhanced for clarity and flow]`,
        'grammar': `${selection.replace(/grammer/g, 'grammar').replace(/readibility/g, 'readability')}\n\n[✓ Grammar fixed]`,
        'summarise': `Summary: ${selection.split(' ').slice(0, 10).join(' ')}...\n\n[📝 Key points extracted]`,
        'explain': `Explanation: This text discusses ${selection.toLowerCase().substring(0, 30)}...\n\n[💡 Simplified explanation]`,
        'professional': `${selection.replace(/hey/gi, 'Dear colleague')}\n\n[👔 Professional tone applied]`
      };
      
      let responseText = mockResponses.improve;
      
      if (instruction.includes('grammar')) responseText = mockResponses.grammar;
      else if (instruction.includes('summarise')) responseText = mockResponses.summarise;
      else if (instruction.includes('explain')) responseText = mockResponses.explain;
      else if (instruction.includes('professional')) responseText = mockResponses.professional;
      else if (instruction.includes('improve')) responseText = mockResponses.improve;
      
      return { text: responseText };
    }
  };

  // Initialize components
  state.badge = createEnhancedBadge();
  state.panel = createEnhancedPanel();
  state.chat = await createChatOverlay();
  
  // Load saved preferences
  const savedSettings = await utils.loadSettings();
  state.isDarkTheme = savedSettings.theme === 'dark';
  if (state.panel) {
    state.panel.setModel(savedSettings.model);
    state.panel.setTheme(state.isDarkTheme);
  }

  // Badge click handler
  state.badge.onClick(() => {
    if (!state.selectionText) return;
    if (!state.selectionRect) return;
    state.panel.open(state.selectionRect, state.selectionText);
  });

  // Panel event handlers
  state.panel.onCancel(() => {
    state.panel.close();
    state.badge.hide();
    state.lastCloseTime = Date.now();
  });

  state.panel.onSubmit(async (instruction) => {
    if (!state.selectionText) {
      state.panel.showError('Select text first to send a request.');
      return;
    }
    state.panel.setLoading(true, 'Processing...');
    try {
      const response = await utils.sendMessage({
        type: 'wandpen:selection-chat',
        selection: state.selectionText,
        instruction: instruction || ''
      });
      if (response?.error) throw new Error(response.error);
      const text = response.text || '';
      state.panel.showResult(text);
    } catch (error) {
      state.panel.showError(error.message || 'Something went wrong.');
    } finally {
      state.panel.setLoading(false);
    }
  });

  state.panel.onInsert((text) => {
    applyResult(text);
    state.panel.close();
    state.badge.hide();
  });

  state.panel.onCopy(async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      state.panel.showStatus('Copied to clipboard.');
    } catch (error) {
      state.panel.showError('Clipboard blocked. Copy manually.');
    }
  });

  // Enhanced selection detection with debouncing
  const handleSelectionChange = utils.debounce(() => {
    if (state.suppressSelectionUpdates || state.panel.isOpen()) {
      return;
    }
    
    // Check if we recently closed
    const timeSinceClose = Date.now() - state.lastCloseTime;
    if (timeSinceClose < 500) {
      return;
    }
    
    requestAnimationFrame(updateSelectionState);
  }, 100);

  // Multiple event listeners for robust selection detection
  document.addEventListener('selectionchange', handleSelectionChange);

  document.addEventListener('mouseup', (event) => {
    const timeSinceClose = Date.now() - state.lastCloseTime;
    
    if (state.panel.isOpen() || timeSinceClose < 500) return;
    
    const path = event.composedPath();
    if (path.includes(state.badge.getElement()) || 
        path.includes(state.panel.getElement())) {
      return;
    }
    
    // Delay to ensure selection is complete
    setTimeout(() => {
      if (!state.suppressSelectionUpdates && !state.panel.isOpen()) {
        handleSelectionChange();
      }
    }, 10);
  });

  // Enhanced keyboard selection detection
  document.addEventListener('keyup', (event) => {
    // Detect selection with keyboard shortcuts
    const selectionKeys = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 
                          'Home', 'End', 'PageUp', 'PageDown'];
    const isSelectionKey = event.shiftKey && selectionKeys.includes(event.key);
    const isSelectAllKey = (event.ctrlKey || event.metaKey) && event.key === 'a';
    
    if (isSelectionKey || isSelectAllKey) {
      if (!state.suppressSelectionUpdates && !state.panel.isOpen()) {
        handleSelectionChange();
      }
    }
  });

  // Enhanced scroll handling with RAF and throttling
  const handleScroll = utils.throttle(() => {
    if (state.scrollRAF) cancelAnimationFrame(state.scrollRAF);
    
    state.scrollRAF = requestAnimationFrame(() => {
      if (state.badge.isVisible() && state.selectionRect) {
        // Update badge position smoothly
        const updatedRect = recalculateSelectionRect();
        if (updatedRect) {
          state.selectionRect = updatedRect;
          state.badge.updatePosition(updatedRect);
        } else {
          state.badge.hide();
        }
      }
      
      if (state.panel.isOpen() && state.selectionRect) {
        const updatedRect = recalculateSelectionRect();
        if (updatedRect) {
          state.selectionRect = updatedRect;
          state.panel.updatePosition(updatedRect);
        }
      }
    });
  }, 50);

  window.addEventListener('scroll', handleScroll, { passive: true });

  // Enhanced resize handling
  const handleResize = utils.debounce(() => {
    if (state.resizeRAF) cancelAnimationFrame(state.resizeRAF);
    
    state.resizeRAF = requestAnimationFrame(() => {
      if (state.panel.isOpen() && state.selectionRect) {
        state.panel.updatePosition(state.selectionRect);
      }
      
      if (state.badge.isVisible() && state.selectionRect) {
        state.badge.updatePosition(state.selectionRect);
      }
    });
  }, 150);

  window.addEventListener('resize', handleResize);

  // Message handler for commands
  chrome.runtime.onMessage.addListener((message) => {
    if (!message?.type) return;
    
    switch(message.type) {
      case 'wandpen:toggle-chat':
        state.chat.toggle();
        break;
        
      case 'wandpen:context-action':
        if (!captureCurrentSelection()) return;
        const preset = message.action === 'grammar' 
          ? 'Fix grammar, spelling, and clarity.' 
          : 'Rewrite for clarity and conciseness.';
        state.panel.open(state.selectionRect, state.selectionText, preset);
        break;
    }
  });

  // Chat message handler
  state.chat.onSend(async (prompt) => {
    if (!prompt.trim()) return;
    const history = state.chat.getHistory();
    state.chat.pushMessage({ role: 'user', content: prompt });
    state.chat.setLoading(true);
    
    try {
      const response = await utils.sendMessage({
        type: 'wandpen:chat-message',
        history,
        prompt
      });
      if (response?.error) throw new Error(response.error);
      state.chat.pushMessage({ role: 'assistant', content: response.text || '' });
    } catch (error) {
      state.chat.pushMessage({ 
        role: 'assistant', 
        content: `Error: ${error.message}` 
      });
    } finally {
      state.chat.setLoading(false);
    }
  });

  // Expose state for debugging
  if (state.debug) {
    window.__wandpenState = state;
  }

  function updateSelectionState() {
    const timeSinceClose = Date.now() - state.lastCloseTime;
    const REOPEN_DELAY = 500;
    
    if (timeSinceClose < REOPEN_DELAY) {
      return;
    }
    
    if (captureCurrentSelection()) {
      state.badge.show(state.selectionRect);
    } else {
      state.badge.hide();
    }
  }

  function captureCurrentSelection() {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
      state.selectionText = '';
      state.selectionRect = null;
      return false;
    }
    
    const text = selection.toString();
    if (!text || !text.trim()) {
      state.selectionText = '';
      state.selectionRect = null;
      return false;
    }

    const range = selection.getRangeAt(0).cloneRange();
    let rect = getAccurateBoundingRect(range);
    
    if (!rect || (rect.width === 0 && rect.height === 0)) {
      state.selectionText = '';
      state.selectionRect = null;
      return false;
    }
    
    const normalizedRect = normaliseRect(rect);
    if (!normalizedRect) {
      state.selectionText = '';
      state.selectionRect = null;
      return false;
    }

    state.selectionText = text.trim();
    state.selectionRange = range;
    state.selectionEditable = closestEditable(selection.anchorNode);
    state.selectionRect = normalizedRect;
    state.lastSelectionTime = Date.now();
    
    return true;
  }

  function recalculateSelectionRect() {
    if (!state.selectionRange) return null;
    
    try {
      const rect = getAccurateBoundingRect(state.selectionRange);
      if (!rect || (rect.width === 0 && rect.height === 0)) {
        return null;
      }
      return normaliseRect(rect);
    } catch (error) {
      return null;
    }
  }

  function getAccurateBoundingRect(range) {
    // Try multiple methods to get accurate bounding rect
    let rect = range.getBoundingClientRect();
    
    if (rect && rect.width > 0 && rect.height > 0) {
      return rect;
    }
    
    const rects = range.getClientRects();
    if (rects && rects.length > 0) {
      let combinedRect = rects[0];
      
      if (rects.length > 1) {
        let minX = combinedRect.left, minY = combinedRect.top;
        let maxX = combinedRect.right, maxY = combinedRect.bottom;
        
        for (let i = 1; i < rects.length; i++) {
          const r = rects[i];
          minX = Math.min(minX, r.left);
          minY = Math.min(minY, r.top);
          maxX = Math.max(maxX, r.right);
          maxY = Math.max(maxY, r.bottom);
        }
        
        combinedRect = {
          left: minX,
          top: minY,
          right: maxX,
          bottom: maxY,
          width: maxX - minX,
          height: maxY - minY
        };
      }
      
      return combinedRect;
    }
    
    const container = range.commonAncestorContainer;
    if (container.nodeType === Node.TEXT_NODE && container.parentElement) {
      return container.parentElement.getBoundingClientRect();
    } else if (container.nodeType === Node.ELEMENT_NODE) {
      return container.getBoundingClientRect();
    }
    
    return null;
  }

  function applyResult(newText) {
    if (!newText) return;
    const editable = state.selectionEditable;
    
    if (editable && typeof editable.value === 'string' && 'setRangeText' in editable) {
      const start = editable.selectionStart ?? 0;
      const end = editable.selectionEnd ?? 0;
      editable.setRangeText(newText, start, end, 'end');
      editable.dispatchEvent(new Event('input', { bubbles: true }));
      editable.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (state.selectionRange) {
      const range = state.selectionRange;
      const textNode = document.createTextNode(newText);
      range.deleteContents();
      range.insertNode(textNode);
      const selection = window.getSelection();
      selection.removeAllRanges();
      const newRange = document.createRange();
      newRange.setStartAfter(textNode);
      newRange.collapse(true);
      selection.addRange(newRange);
      dispatchInputEvent(textNode.parentElement || textNode);
    }
    
    state.selectionRange = null;
    state.selectionEditable = null;
    state.selectionText = '';
  }

  function dispatchInputEvent(node) {
    if (!node) return;
    const element = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    if (!element) return;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function closestEditable(node) {
    if (!node) return null;
    let el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    while (el) {
      if (el.isContentEditable) return el;
      if (el.tagName === 'TEXTAREA') return el;
      if (el.tagName === 'INPUT' && /^(text|search|email|tel|url)$/i.test(el.type)) {
        return el;
      }
      el = el.parentElement;
    }
    return document.activeElement;
  }

  function normaliseRect(rect) {
    if (!rect) return null;
    if (rect.width === 0 && rect.height === 0) return null;
    
    const top = typeof rect.top === 'number' ? rect.top : 0;
    const left = typeof rect.left === 'number' ? rect.left : 0;
    const width = typeof rect.width === 'number' ? rect.width : 0;
    const height = typeof rect.height === 'number' ? rect.height : 0;
    
    return {
      top: top + window.scrollY,
      left: left + window.scrollX,
      width: width,
      height: height,
      bottom: top + height + window.scrollY,
      right: left + width + window.scrollX
    };
  }

  function calculateSmartPosition(rect, elementWidth, elementHeight) {
    const margin = 12;
    const viewport = {
      width: window.innerWidth,
      height: window.innerHeight,
      scrollX: window.scrollX,
      scrollY: window.scrollY
    };
    
    // Start with preferred position
    let left = rect.left + (rect.width / 2) - (elementWidth / 2);
    let top = rect.top - elementHeight - margin;
    
    // Advanced collision detection
    const viewportRight = viewport.scrollX + viewport.width;
    const viewportBottom = viewport.scrollY + viewport.height;
    
    // Horizontal bounds
    if (left + elementWidth > viewportRight - margin) {
      left = viewportRight - elementWidth - margin;
    }
    if (left < viewport.scrollX + margin) {
      left = viewport.scrollX + margin;
    }
    
    // Vertical bounds with smart positioning
    if (top < viewport.scrollY + margin) {
      // Try below
      top = rect.bottom + margin;
      
      if (top + elementHeight > viewportBottom - margin) {
        // Find best position
        const spaceAbove = rect.top - viewport.scrollY;
        const spaceBelow = viewportBottom - rect.bottom;
        
        if (spaceAbove > spaceBelow && spaceAbove >= elementHeight + margin) {
          top = rect.top - elementHeight - margin;
        } else if (spaceBelow >= elementHeight + margin) {
          top = rect.bottom + margin;
        } else {
          // Center in viewport
          top = viewport.scrollY + Math.max(margin, (viewport.height - elementHeight) / 2);
        }
      }
    }
    
    // Final bounds check
    left = Math.max(viewport.scrollX + margin, 
                   Math.min(left, viewportRight - elementWidth - margin));
    top = Math.max(viewport.scrollY + margin, 
                  Math.min(top, viewportBottom - elementHeight - margin));
    
    return { left, top };
  }

  function createEnhancedBadge() {
    const host = document.createElement('div');
    host.id = 'wandpen-badge-host';
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = BADGE_CSS;
    shadow.appendChild(style);

    const wrapper = document.createElement('div');
    wrapper.className = 'badge-wrapper';
    wrapper.innerHTML = `
      <div class="badge">
        <div class="badge-icon">W</div>
        <div class="badge-tooltip">Open WandPen</div>
      </div>
    `;
    shadow.appendChild(wrapper);

    const badge = wrapper.querySelector('.badge');
    let isVisible = false;
    let handler = () => {};

    badge.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      handler();
    });
    
    // Enhanced click-outside detection
    const handleClickOutside = (event) => {
      if (!isVisible) return;
      
      const path = event.composedPath();
      const isInsideBadge = path.includes(wrapper) || 
                           path.includes(host) || 
                           event.target === host ||
                           event.target.closest('#wandpen-badge-host');
      
      if (!isInsideBadge && !event.target.closest('#wandpen-panel-host')) {
        state.lastCloseTime = Date.now();
        state.suppressSelectionUpdates = true;
        wrapper.classList.remove('visible');
        isVisible = false;
        
        setTimeout(() => {
          state.suppressSelectionUpdates = false;
        }, 600);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside, true);

    return {
      show(rect) {
        const badgeWidth = 36;
        const badgeHeight = 36;
        const position = calculateSmartPosition(rect, badgeWidth, badgeHeight);
        
        // Position with micro-adjustments for better UX
        wrapper.style.top = `${position.top - 5}px`;
        wrapper.style.left = `${position.left + rect.width + 10}px`;
        
        // Smooth appearance
        requestAnimationFrame(() => {
          wrapper.classList.add('visible');
          isVisible = true;
        });
      },
      
      hide() {
        wrapper.classList.remove('visible');
        isVisible = false;
      },
      
      isVisible() {
        return isVisible;
      },
      
      getElement() {
        return wrapper;
      },
      
      onClick(fn) {
        handler = fn;
      },
      
      updatePosition(rect) {
        if (isVisible && rect) {
          const badgeWidth = 36;
          const badgeHeight = 36;
          const position = calculateSmartPosition(rect, badgeWidth, badgeHeight);
          
          wrapper.style.top = `${position.top - 5}px`;
          wrapper.style.left = `${position.left + rect.width + 10}px`;
        }
      }
    };
  }

  function createEnhancedPanel() {
    const host = document.createElement('div');
    host.id = 'wandpen-panel-host';
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = PANEL_CSS;
    shadow.appendChild(style);

    const panel = document.createElement('div');
    panel.className = 'panel';
    panel.innerHTML = `
      <!-- Theme Toggle -->
      <button class="theme-toggle" type="button" aria-label="Toggle dark theme">
        <div class="theme-toggle-icon">☀️</div>
      </button>
      
      <!-- Search Input -->
      <div class="search-section">
        <div class="search-input-wrapper">
          <svg class="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <input
            type="text"
            id="search-input"
            placeholder="Search or enter a custom prompt"
            class="search-input"
          />
        </div>
      </div>

      <!-- Menu Items -->
      <div class="menu-section">
        <button class="menu-item active" data-action="improve">
          <svg class="menu-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.582a.5.5 0 0 1 0 .962L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>
          </svg>
          <span>Improve writing</span>
        </button>

        <button class="menu-item" data-action="summarise">
          <svg class="menu-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
            <polyline points="14,2 14,8 20,8"></polyline>
            <line x1="16" y1="13" x2="8" y2="13"></line>
            <line x1="16" y1="17" x2="8" y2="17"></line>
            <polyline points="10,9 9,9 8,9"></polyline>
          </svg>
          <span>Summarise</span>
        </button>

        <button class="menu-item" data-action="grammar">
          <svg class="menu-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20,6 9,17 4,12"></polyline>
          </svg>
          <span>Fix grammar</span>
        </button>

        <button class="menu-item" data-action="explain">
          <svg class="menu-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 12l2 2 4-4"></path>
            <circle cx="12" cy="12" r="10"></circle>
          </svg>
          <span>What is this?</span>
        </button>

        <button class="menu-item" data-action="professional">
          <svg class="menu-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
            <line x1="8" y1="21" x2="16" y2="21"></line>
            <line x1="12" y1="17" x2="12" y2="21"></line>
          </svg>
          <span>Write professionally</span>
        </button>

        <button class="menu-item" data-action="custom">
          <svg class="menu-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
          <span>Use custom prompt:</span>
        </button>
      </div>
      
      <div class="custom-prompt">
        <textarea class="custom-input" placeholder="Enter your custom prompt..."></textarea>
        <div class="custom-actions">
          <button type="button" class="btn-secondary cancel-custom">Cancel</button>
          <button type="button" class="btn-primary submit-custom">Send</button>
        </div>
      </div>
      
      <div class="result-container">
        <div class="result-text"></div>
        <div class="result-actions">
          <button type="button" class="btn-secondary copy-result">Copy</button>
          <button type="button" class="btn-primary insert-result">Insert</button>
        </div>
      </div>

      <!-- Footer -->
      <div class="footer-section">
        <span class="footer-empty"></span>
        <button class="model-selector" id="model-button">
          <span>gemini</span>
          <svg class="chevron-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="6,9 12,15 18,9"></polyline>
          </svg>
        </button>
      </div>
      
      <!-- Glass Blur Loading Overlay -->
      <div class="loading-overlay">
        <div class="loading-spinner"></div>
      </div>
    `;
    shadow.appendChild(panel);

    // Get all elements
    const searchInput = panel.querySelector('#search-input');
    const menuItems = panel.querySelectorAll('.menu-item');
    const resultContainer = panel.querySelector('.result-container');
    const resultText = panel.querySelector('.result-text');
    const insertBtn = panel.querySelector('.insert-result');
    const copyBtn = panel.querySelector('.copy-result');
    const modelButton = panel.querySelector('#model-button');
    const customPrompt = panel.querySelector('.custom-prompt');
    const customInput = panel.querySelector('.custom-input');
    const submitCustomBtn = panel.querySelector('.submit-custom');
    const cancelCustomBtn = panel.querySelector('.cancel-custom');
    const loadingOverlay = panel.querySelector('.loading-overlay');
    const themeToggle = panel.querySelector('.theme-toggle');
    const themeToggleIcon = panel.querySelector('.theme-toggle-icon');
    
    const statusEl = document.createElement('div');
    statusEl.className = 'status';
    panel.appendChild(statusEl);
    
    let insertHandler = () => {};
    let copyHandler = () => {};
    let cancelHandler = () => {};
    let submitHandler = () => {};
    let currentModel = 'gemini';
    let chatContext = [];
    let latestResponse = '';
    let isOpen = false;

    // Functions
    async function handleQuickAction(action) {
      const prompts = {
        improve: 'Improve the writing quality, clarity, and flow of this text while maintaining its original meaning',
        grammar: 'Fix grammar, spelling, and punctuation errors in this text',
        explain: 'Explain what this text means in simple terms',
        professional: 'Rewrite this text to sound more professional and polished',
        summarise: 'Provide a concise summary of this text'
      };
      
      const prompt = prompts[action];
      if (prompt && state.selectionText) {
        await sendToLLM(prompt);
      }
    }

    async function handleCustomPrompt(prompt) {
      console.log('🎯 handleCustomPrompt called with:', {
        prompt,
        hasSelection: !!state.selectionText,
        selectionText: state.selectionText?.substring(0, 50) + '...'
      });
      
      if (!prompt) {
        console.warn('❌ No prompt provided to handleCustomPrompt');
        return;
      }
      
      if (!state.selectionText) {
        console.warn('❌ No text selected for custom prompt');
        setError('Please select some text first.');
        // Don't clear the input if there's no selection, so user can fix it
        customPrompt.classList.remove('visible');
        return;
      }
      
      console.log('✅ Proceeding with custom prompt');
      customPrompt.classList.remove('visible');
      customInput.value = '';
      await sendToLLM(prompt);
    }

    async function sendToLLM(instruction) {
      setLoading(true, 'Processing...');
      
      console.log('🔍 Debug Info:', {
        hasSelection: !!state.selectionText,
        selectionLength: state.selectionText?.length,
        instruction,
        model: currentModel,
        chromeRuntime: !!chrome?.runtime,
        extensionId: chrome?.runtime?.id
      });
      
      try {
        const messagePayload = {
          type: 'wandpen:selection-chat',
          selection: state.selectionText,
          instruction: instruction,
          model: currentModel
        };
        
        console.log('📤 Sending message:', messagePayload);
        
        const response = await utils.sendMessage(messagePayload);
        
        console.log('📥 Received response:', response);
        
        if (response?.error) throw new Error(response.error);
        
        chatContext = [{ role: 'user', content: instruction }];
        chatContext.push({ role: 'assistant', content: response.text || '' });
        latestResponse = response.text || '';
        
        showResult(response.text || '');
        
      } catch (error) {
        console.error('🚨 sendToLLM error:', error);
        showError(error.message || 'Something went wrong.');
      } finally {
        setLoading(false);
      }
    }

    function setLoading(isLoading, message = '') {
      if (isLoading) {
        loadingOverlay.classList.add('visible');
        statusEl.innerHTML = `<div class="loading"><div class="spinner"></div>${message}</div>`;
        statusEl.classList.remove('error');
      } else {
        loadingOverlay.classList.remove('visible');
        statusEl.innerHTML = '';
      }
    }

    function showResult(text) {
      resultText.textContent = text;
      resultContainer.classList.add('visible');
      statusEl.textContent = 'Result ready';
      statusEl.classList.remove('error');
      
      setTimeout(() => {
        resultContainer.scrollIntoView({ behavior: 'smooth', block: 'end' });
      }, 150);
    }

    function showError(message) {
      statusEl.textContent = message;
      statusEl.classList.add('error');
    }
    
    function clearResult() {
      resultContainer.classList.remove('visible');
      resultText.textContent = '';
      chatContext = [];
      latestResponse = '';
    }

    // Event handlers
    menuItems.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        menuItems.forEach(item => item.classList.remove('active'));
        btn.classList.add('active');
        
        const action = btn.dataset.action;
        if (action === 'custom') {
          customPrompt.classList.add('visible');
          customInput.focus();
        } else {
          handleQuickAction(action);
        }
      });
    });

    submitCustomBtn.addEventListener('click', () => {
      console.log('🖱️ Submit custom button clicked');
      const prompt = customInput.value.trim();
      console.log('📝 Custom input value:', prompt);
      if (prompt) {
        handleCustomPrompt(prompt);
      } else {
        console.warn('❌ Empty prompt, not submitting');
      }
    });

    cancelCustomBtn.addEventListener('click', () => {
      customPrompt.classList.remove('visible');
      customInput.value = '';
    });

    customInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        // If Shift+Enter, allow newline (don't prevent default)
        if (e.shiftKey) {
          return;
        }
        // For plain Enter, submit the prompt
        e.preventDefault();
        const prompt = customInput.value.trim();
        if (prompt) {
          console.log('🚀 Custom prompt submitted via Enter key:', prompt);
          handleCustomPrompt(prompt);
        }
      }
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && searchInput.value.trim()) {
        e.preventDefault();
        handleCustomPrompt(searchInput.value.trim());
      }
    });

    insertBtn.addEventListener('click', () => {
      insertHandler(latestResponse);
    });

    copyBtn.addEventListener('click', () => {
      copyHandler(latestResponse);
    });
    
    themeToggle.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      state.isDarkTheme = !state.isDarkTheme;
      
      if (state.isDarkTheme) {
        panel.classList.add('dark-theme');
        themeToggle.classList.add('dark');
        themeToggleIcon.innerHTML = '🌙';
      } else {
        panel.classList.remove('dark-theme');
        themeToggle.classList.remove('dark');
        themeToggleIcon.innerHTML = '☀️';
      }
      
      // Save preference (gracefully handles extension context issues)
      await utils.saveSettings({ 
        theme: state.isDarkTheme ? 'dark' : 'light',
        model: currentModel 
      });
    });
    
    // Enhanced click-outside detection
    const handleClickOutside = (event) => {
      if (!isOpen) return;
      
      const path = event.composedPath();
      const isInsidePanel = path.includes(panel) || 
                          path.includes(host) ||
                          event.target === host ||
                          event.target.closest('#wandpen-panel-host');
      
      if (!isInsidePanel && !event.target.closest('#wandpen-badge-host')) {
        state.lastCloseTime = Date.now();
        state.suppressSelectionUpdates = true;
        state.badge.hide();
        cancelHandler();
        
        setTimeout(() => {
          state.suppressSelectionUpdates = false;
        }, 600);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside, true);
    
    // Escape key handler
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && isOpen) {
        state.lastCloseTime = Date.now();
        state.suppressSelectionUpdates = true;
        state.badge.hide();
        cancelHandler();
        
        setTimeout(() => {
          state.suppressSelectionUpdates = false;
        }, 600);
      }
    });

    return {
      open(rect, selectionText, presetInstruction = '') {
        state.suppressSelectionUpdates = true;
        isOpen = true;
        
        // Reset UI
        statusEl.innerHTML = '';
        statusEl.classList.remove('error');
        customPrompt.classList.remove('visible');
        customInput.value = '';
        searchInput.value = '';
        clearResult();
        
        // Position panel
        const position = calculateSmartPosition(rect, 350, 235);
        panel.style.top = `${position.top}px`;
        panel.style.left = `${position.left}px`;
        
        panel.classList.add('visible', 'show');
        
        // Handle preset
        if (presetInstruction) {
          if (presetInstruction.includes('grammar')) {
            handleQuickAction('grammar');
          } else if (presetInstruction.includes('improve')) {
            handleQuickAction('improve');
          } else {
            customPrompt.classList.add('visible');
            customInput.value = presetInstruction;
            setTimeout(() => customInput.focus(), 100);
          }
        }
        
        setTimeout(() => {
          state.suppressSelectionUpdates = false;
        }, 100);
      },
      
      close() {
        isOpen = false;
        panel.classList.add('hide');
        panel.classList.remove('show');
        setTimeout(() => {
          panel.classList.remove('visible', 'hide');
          customPrompt.classList.remove('visible');
          clearResult();
          statusEl.innerHTML = '';
          searchInput.value = '';
        }, 200);
      },
      
      isOpen() {
        return isOpen;
      },
      
      setLoading(isLoading, message) {
        setLoading(isLoading, message);
      },
      
      showResult(text) {
        showResult(text);
      },
      
      showError(message) {
        showError(message);
      },
      
      showStatus(message) {
        statusEl.textContent = message;
        statusEl.classList.remove('error');
      },
      
      onSubmit(handler) {
        submitHandler = handler;
      },
      
      onInsert(handler) {
        insertHandler = handler;
      },
      
      onCopy(handler) {
        copyHandler = handler;
      },
      
      onCancel(handler) {
        cancelHandler = handler;
      },
      
      getElement() {
        return panel;
      },
      
      setModel(model) {
        currentModel = model;
        const modelText = modelButton.querySelector('span');
        if (modelText) {
          modelText.textContent = model;
        }
      },
      
      setTheme(isDark) {
        if (isDark) {
          panel.classList.add('dark-theme');
          themeToggle.classList.add('dark');
          themeToggleIcon.innerHTML = '🌙';
        } else {
          panel.classList.remove('dark-theme');
          themeToggle.classList.remove('dark');
          themeToggleIcon.innerHTML = '☀️';
        }
      },
      
      updatePosition(rect) {
        if (isOpen && rect) {
          const position = calculateSmartPosition(rect, 350, 235);
          panel.style.top = `${position.top}px`;
          panel.style.left = `${position.left}px`;
        }
      }
    };
  }

  async function createChatOverlay() {
    const container = document.createElement('div');
    container.id = 'wandpen-chat-host';
    document.documentElement.appendChild(container);

    const shadow = container.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = `
      :host { all: initial; }
      .overlay {
        position: fixed;
        inset: 0;
        background: rgba(15, 23, 42, 0.55);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 2147483645;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Inter', sans-serif;
      }
      .overlay.visible {
        display: flex;
      }
      .panel {
        width: min(600px, 90vw);
        max-height: 80vh;
        background: #f8fafc;
        border-radius: 18px;
        box-shadow: 0 30px 60px rgba(15, 23, 42, 0.35);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        animation: chatPanelAppear 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      }
      @keyframes chatPanelAppear {
        from {
          opacity: 0;
          transform: scale(0.95) translateY(20px);
        }
        to {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }
      header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 20px;
        border-bottom: 1px solid rgba(15, 23, 42, 0.1);
      }
      header h2 {
        margin: 0;
        font-size: 18px;
      }
      header button {
        border: none;
        background: transparent;
        font-size: 22px;
        cursor: pointer;
        color: #475569;
      }
      .history {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        background: #e2e8f0;
      }
      .message {
        padding: 12px 14px;
        border-radius: 12px;
        line-height: 1.55;
        white-space: pre-wrap;
        max-width: 80%;
        animation: messageAppear 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      }
      @keyframes messageAppear {
        from {
          opacity: 0;
          transform: translateY(10px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
      .message.user {
        align-self: flex-end;
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: #fff;
      }
      .message.assistant {
        align-self: flex-start;
        background: #fff;
        color: #0f172a;
        border: 1px solid rgba(102, 126, 234, 0.2);
      }
      form {
        padding: 16px 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        border-top: 1px solid rgba(15, 23, 42, 0.1);
      }
      textarea {
        border-radius: 12px;
        border: 1px solid rgba(148, 163, 184, 0.5);
        padding: 12px 14px;
        resize: vertical;
        min-height: 90px;
        font-size: 14px;
        font-family: inherit;
      }
      textarea:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
      }
      .actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
      }
      .actions button {
        border: none;
        border-radius: 12px;
        padding: 10px 18px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
      }
      .actions .send {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: #fff;
      }
      .actions .send:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
      }
      .actions .send:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none;
      }
    `;
    shadow.appendChild(style);

    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML = `
      <div class="panel">
        <header>
          <h2>WandPen Chat</h2>
          <button type="button" class="close">×</button>
        </header>
        <div class="history"></div>
        <form>
          <textarea placeholder="Ask WandPen anything…"></textarea>
          <div class="actions">
            <button type="submit" class="send">Send</button>
          </div>
        </form>
      </div>
    `;
    shadow.appendChild(overlay);

    const historyEl = overlay.querySelector('.history');
    const textarea = overlay.querySelector('textarea');
    const closeBtn = overlay.querySelector('.close');
    const form = overlay.querySelector('form');
    const sendBtn = overlay.querySelector('.send');

    closeBtn.addEventListener('click', () => api.toggle(false));
    overlay.addEventListener('mousedown', (event) => {
      if (event.target === overlay) api.toggle(false);
    });

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const value = textarea.value.trim();
      if (!value) return;
      textarea.value = '';
      onSend(value);
    });

    let onSend = () => {};

    const api = {
      toggle(force) {
        const next = typeof force === 'boolean' ? force : !overlay.classList.contains('visible');
        overlay.classList.toggle('visible', next);
        if (next) {
          textarea.focus();
        }
      },
      setLoading(isLoading) {
        sendBtn.disabled = Boolean(isLoading);
      },
      pushMessage(message) {
        const div = document.createElement('div');
        div.className = `message ${message.role}`;
        div.textContent = message.content;
        historyEl.appendChild(div);
        historyEl.scrollTop = historyEl.scrollHeight;
      },
      getHistory() {
        const messages = [];
        historyEl.querySelectorAll('.message').forEach((node) => {
          const role = node.classList.contains('user') ? 'user' : 'assistant';
          messages.push({ role, content: node.textContent || '' });
        });
        return messages;
      },
      onSend(handler) {
        onSend = handler;
      },
      onToggle() {}
    };

    return api;
  }
  
  console.log('🎉 WandPen content script fully loaded and ready!');
})();